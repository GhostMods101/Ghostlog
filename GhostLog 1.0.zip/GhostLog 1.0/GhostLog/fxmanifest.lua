fx_version 'cerulean'
game 'gta5'

author 'GhostModz'
description 'Deathlog with Images'
version '1.0'
repo 'https://github.com/GhostMods101?tab=repositories'


client_scripts {
    'client/*.lua',
}

server_scripts {
    'server/*.lua',
}

shared_scripts {
    'config.lua',
}

dependencies {
	'screenshot-basic',
}



