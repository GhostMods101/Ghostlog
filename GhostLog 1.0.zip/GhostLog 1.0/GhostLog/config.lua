Config = {}


Config.Debug = false

Config.Discord = {
    Settings = {
        Webhook = 'PLACE YOUR WEBHOOK HERE',
        Name = 'Ghost Log Player Deaths',
        Images = 'https://i.imgur.com/t4SNTk5.png'
    },
}

